<?php
require 'Send_Mail.php';
$to = "sahilakshay.jain@gmail.com";
$subject = "Test Mail Subject";
$body = "Hi<br/>Test Mail<br/>Indian Sweets"; // HTML  tags
$status=Send_Mail($to,$subject,$body);
if(!$status)
    echo "NOT SENT";
else
    echo "SENT";
?>