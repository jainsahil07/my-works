<?php
date_default_timezone_set("ASIA/KOLKATA");
function Send_Mail($to,$subject,$body)
{
	require 'class.phpmailer.php';
	$from = "info@thewebstrike.com";
	$mail = new PHPMailer();
	$mail->IsSMTP(true); // SMTP
	$mail->SMTPAuth   = true;  // SMTP authentication
	$mail->Mailer = "smtp";
	$mail->Host       = "tls://smtpout.asia.secureserver.net"; // Amazon SES server/server url, note "tls://" protocol
	$mail->Port       = 465;                // set the SMTP port
	$mail->Username   = "info@thewebstrike.com";  // SES SMTP  username
	$mail->Password   = "info@thewebstrike.com";  // SES SMTP password
	$mail->SetFrom($from, 'SPF'); //name
	$mail->AddReplyTo($from,'SPF'); //name
	$mail->Subject = $subject;
	$mail->MsgHTML($body);
	$address = $to;
	$mail->AddAddress($address, $to);

	if(!$mail->Send())
	{
		return false;
	}
	else
	{
		return true;
	}
}
?>