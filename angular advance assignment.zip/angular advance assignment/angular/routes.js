myApp.config( ['$routeProvider' ,'$locationProvider'  , function($routeProvider , $locationProvider ){
    $routeProvider
	.when('/index.html',{
		templateUrl		: 'views/index-view.html',
	    controller 		: 'mainCtrl',
		controllerAs 	: 'allBooks'
	})
	.otherwise(
	    {
	        redirectTo:'<h1>404 page not found</h1>'
	    }
	);
    
}]);