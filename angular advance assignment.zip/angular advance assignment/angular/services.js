
//myApp.factory('TvSeriesService',function TvSeriesFactory($http,$q){





var myApp = angular.module('TvSeriesApp' , ['ngRoute']);

myApp.service('todoPromisedService', ['$http', '$q', function($http, $q) {
    this.getTodos = function() {
      var deferred = $q.defer();
        $http.get('http://www.anapioficeandfire.com/api/books')
        .success(function(todos) {
            deferred.resolve(todos);
			console.log(todos);
        })
        .error(function() {
            deferred.reject('oh shit!');
        });
      return deferred.promise;
    };
    
}]);
